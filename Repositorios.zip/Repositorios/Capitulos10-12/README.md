# Capitulos10-12
Hacer Auto evaluación y Ejercicios Capítulos 10 y 12 del Libro C# Guía del programador Total.
