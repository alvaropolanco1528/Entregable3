﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CuentaBancaria
{
    public struct CuentaBancariaDatos
    {
        public string NumeroCuenta { get; set; }
        public string NombrePropietario { get; set; }
        public string DineroCuenta { get; set; }
        public string UsuarioCuenta { get; set; }
        public string ConstrañaCuenta { get; set; }

    }
}
