﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ej1
{
   public struct EstructuraTienda
    {
        
    public string Precio { get; set; }
    public string NombreProducto { get; set; }
    public string CodigoBarras { get; set; }
    public string Cantidad { get; set; }
      

    }
}
